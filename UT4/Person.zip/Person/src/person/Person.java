package person;


public class Person {
    private String name;
    private String surnames;
    private int age;
    private int id;
    
    public Person(int id, String name, String surnames, int age){
        this.id = id;
        this.name = name;
        this.surnames = surnames;
        this.age = age;
    }
    
    public void concentrate() {
    
    }
    
    public void travel(){
        
    }
}
